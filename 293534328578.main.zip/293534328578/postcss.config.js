/** WARNING: DON'T EDIT THIS FILE */
/** WARNING: DON'T EDIT THIS FILE */
/** WARNING: DON'T EDIT THIS FILE */

export default {
  plugins: {
    tailwindcss: {},
    autoprefixer: {},
  },
};
