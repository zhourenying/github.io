import { Routes, Route } from "react-router-dom";
import Home from "@/pages/Home";
import ToolsPage from "@/pages/ToolsPage";
import TutorialsPage from "@/pages/TutorialsPage";
import CasesPage from "@/pages/CasesPage";
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import { useState } from "react";
import { AuthContext } from '@/contexts/authContext';

export default function App() {
  const [isAuthenticated, setIsAuthenticated] = useState(false);

  const logout = () => {
    setIsAuthenticated(false);
  };

  return (
    <AuthContext.Provider
      value={{ isAuthenticated, setIsAuthenticated, logout }}
    >
      <div className="min-h-screen flex flex-col">
        <Navbar />
        <main className="flex-grow">
          <Routes>
            <Route path="/" element={<Home />} />
            <Route path="/tools" element={<ToolsPage />} />
            <Route path="/tutorials" element={<TutorialsPage />} />
            <Route path="/cases" element={<CasesPage />} />
          </Routes>
        </main>
        <Footer />
      </div>
    </AuthContext.Provider>
  );
}
