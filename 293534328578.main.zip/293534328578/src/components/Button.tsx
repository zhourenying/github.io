import React, { ReactNode } from 'react';
import { Link } from 'react-router-dom';
import { cn } from '@/lib/utils';

interface ButtonProps {
  children: ReactNode;
  className?: string;
  href?: string;
  onClick?: () => void;
  disabled?: boolean;
  type?: 'button' | 'submit' | 'reset';
}

export const Button: React.FC<ButtonProps> = ({
  children,
  className = '',
  href,
  onClick,
  disabled = false,
  type = 'button'
}) => {
  // 根据是否有href决定使用Link还是button
  const baseClasses = cn(
    'inline-flex items-center justify-center font-medium rounded-lg transition-all duration-200',
    'focus:outline-none focus:ring-2 focus:ring-offset-2',
    disabled 
      ? 'opacity-50 cursor-not-allowed' 
      : 'hover:shadow-md transform hover:-translate-y-0.5',
    className
  );
  
  if (href) {
    return (
      <Link 
        to={href}
        className={baseClasses}
        onClick={onClick}
      >
        {children}
      </Link>
    );
  }
  
  return (
    <button
      type={type}
      className={baseClasses}
      onClick={onClick}
      disabled={disabled}
    >
      {children}
    </button>
  );
};