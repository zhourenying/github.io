import React from 'react';
import { Link } from 'react-router-dom';

const Footer: React.FC = () => {
  // 站点信息
  const siteInfo = {
    name: "AI工具学习平台",
    description: "专为AI工具新手打造的学习资源平台",
    copyright: "© 2025 AI工具学习平台. 保留所有权利."
  };
  
  // 导航链接分组
  const navGroups = [
    {
      title: "快速链接",
      links: [
        { title: "首页", path: "/" },
        { title: "工具分类", path: "/tools" },
        { title: "教程中心", path: "/tutorials" },
        { title: "案例展示", path: "/cases" }
      ]
    },
    {
      title: "关于我们",
      links: [
        { title: "关于平台", path: "/about" },
        { title: "团队介绍", path: "/team" },
        { title: "联系方式", path: "/contact" },
        { title: "隐私政策", path: "/privacy" }
      ]
    },
    {
      title: "资源中心",
      links: [
        { title: "学习路径", path: "/learning-path" },
        { title: "常见问题", path: "/faq" },
        { title: "帮助中心", path: "/help" },
        { title: "更新日志", path: "/changelog" }
      ]
    }
  ];
  
  // 社交媒体链接
  const socialLinks = [
    { name: "Twitter", icon: "fa-twitter", url: "#" },
    { name: "Facebook", icon: "fa-facebook", url: "#" },
    { name: "Instagram", icon: "fa-instagram", url: "#" },
    { name: "GitHub", icon: "fa-github", url: "#" },
    { name: "LinkedIn", icon: "fa-linkedin", url: "#" }
  ];
  
  // 更新日志
  const changelog = [
    { date: "2025-12-15", content: "新增5款AI视频工具和相关教程" },
    { date: "2025-12-01", content: "优化网站响应速度和用户体验" },
    { date: "2025-11-15", content: "增加深色模式支持" }
  ];
  
  return (
    <footer className="bg-gray-50 dark:bg-gray-900 border-t border-gray-200 dark:border-gray-800 pt-16 pb-8">
      <div className="container mx-auto px-4">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-10">
          {/* 站点信息 */}
          <div className="col-span-1 md:col-span-1">
            <div className="flex items-center space-x-2 mb-6">
              <div className="w-10 h-10 bg-blue-600 rounded-lg flex items-center justify-center">
                <i className="fa-robot text-white text-xl"></i>
              </div>
              <span className="text-xl font-bold text-gray-800 dark:text-white">{siteInfo.name}</span>
            </div>
            <p className="text-gray-600 dark:text-gray-400 mb-6">{siteInfo.description}</p>
            
            {/* 社交媒体链接 */}
            <div className="flex space-x-4">
              {socialLinks.map((social, index) => (
                <a
                  key={index}
                  href={social.url}
                  className="w-10 h-10 rounded-full bg-white dark:bg-gray-800 flex items-center justify-center text-gray-600 dark:text-gray-400 hover:bg-blue-600 hover:text-white dark:hover:bg-blue-600 transition-colors"
                  aria-label={social.name}
                >
                  <i className={`fa-brands ${social.icon}`}></i>
                </a>
              ))}
            </div>
          </div>
          
          {/* 导航链接 */}
          {navGroups.map((group, index) => (
            <div key={index} className="col-span-1">
              <h3 className="text-lg font-bold mb-6 text-gray-800 dark:text-white">{group.title}</h3>
              <ul className="space-y-4">
                {group.links.map((link, linkIndex) => (
                  <li key={linkIndex}>
                    <Link
                      to={link.path}
                      className="text-gray-600 dark:text-gray-400 hover:text-blue-600 dark:hover:text-blue-400 transition-colors"
                    >
                      {link.title}
                    </Link>
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>
        
        {/* 更新日志 */}
        <div className="mt-16 p-6 bg-white dark:bg-gray-800 rounded-xl shadow-sm border border-gray-100 dark:border-gray-700">
          <h3 className="text-lg font-bold mb-4 text-gray-800 dark:text-white">
            <i className="fa-calendar-alt mr-2 text-blue-600 dark:text-blue-400"></i>
            近期更新
          </h3>
          <div className="space-y-3">
            {changelog.map((item, index) => (
              <div key={index} className="flex">
                <span className="text-sm font-medium text-blue-600 dark:text-blue-400 w-24">{item.date}</span>
                <span className="text-gray-600 dark:text-gray-400">{item.content}</span>
              </div>
            ))}
          </div>
          <div className="mt-4 text-right">
            <Link
              to="/changelog"
              className="text-blue-600 dark:text-blue-400 hover:text-blue-800 dark:hover:text-blue-300 text-sm font-medium transition-colors"
            >
              查看全部更新 <i className="fa-angle-right ml-1"></i>
            </Link>
          </div>
        </div>
        
        {/* 版权信息 */}
        <div className="mt-10 text-center text-gray-600 dark:text-gray-400 text-sm">
          <p>{siteInfo.copyright}</p>
          <p className="mt-2">定期维护：我们每月进行系统更新和内容优化，确保提供最佳的学习体验</p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;