import React from 'react';
import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { Button } from './Button';

// 工具类型定义
interface Tool {
  id: string;
  name: string;
  category: string;
  description: string;
  features: string[];
  price: string;
  适用场景: string[];
  website: string;
  image: string;
}

interface ToolCardProps {
  tool: Tool;
}

export const ToolCard: React.FC<ToolCardProps> = ({ tool }) => {
  // 获取分类对应的图标和颜色
  const getCategoryInfo = (category: string) => {
    switch(category) {
      case 'text':
        return { icon: 'fa-file-alt', color: 'bg-blue-100 dark:bg-blue-900/50 text-blue-600 dark:text-blue-400' };
      case 'image':
        return { icon: 'fa-image', color: 'bg-purple-100 dark:bg-purple-900/50 text-purple-600 dark:text-purple-400' };
      case 'video':
        return { icon: 'fa-video', color: 'bg-red-100 dark:bg-red-900/50 text-red-600 dark:text-red-400' };
      default:
        return { icon: 'fa-tools', color: 'bg-gray-100 dark:bg-gray-800 text-gray-600 dark:text-gray-400' };
    }
  };
  
  const categoryInfo = getCategoryInfo(tool.category);
  
  // 动画变体
  const cardHover = {
    scale: 1.02,
    boxShadow: '0 20px 25px -5px rgba(0, 0, 0, 0.1), 0 10px 10px -5px rgba(0, 0, 0, 0.04)',
    transition: { duration: 0.2 }
  };
  
  return (
    <motion.div 
      className="bg-white dark:bg-gray-900 rounded-xl overflow-hidden shadow-lg border border-gray-200 dark:border-gray-700"
      whileHover={cardHover}
    >
      {/* 工具图片 */}
      <div className="h-56 overflow-hidden">
        <img 
          src={tool.image} 
          alt={tool.name} 
          className="w-full h-full object-cover transition-transform duration-700 hover:scale-110"
          loading="lazy"
        />
      </div>
      
      {/* 工具信息 */}
      <div className="p-6">
        {/* 分类标签和价格 */}
        <div className="flex justify-between items-center mb-4">
          <span className={`flex items-center gap-2 text-sm font-medium px-3 py-1 rounded-full ${categoryInfo.color}`}>
            <i className={`fa-solid ${categoryInfo.icon}`}></i>
            {tool.category === 'text' ? 'AI文本工具' : 
             tool.category === 'image' ? 'AI绘图工具' : 'AI视频工具'}
          </span>
          <span className="text-sm font-medium text-gray-500 dark:text-gray-400">
            {tool.price}
          </span>
        </div>
        
        {/* 工具名称 */}
        <h3 className="text-2xl font-bold mb-3 text-gray-800 dark:text-white">{tool.name}</h3>
        
        {/* 工具描述 */}
        <p className="text-gray-600 dark:text-gray-400 mb-5 line-clamp-2">{tool.description}</p>
        
        {/* 核心功能 */}
        <div className="mb-6"><h4 className="text-sm font-semibold mb-3 text-gray-500 dark:text-gray-400 uppercase tracking-wider">核心功能</h4>
          <div className="flex flex-wrap gap-2">
            {tool.features.slice(0, 3).map((feature, index) => (
              <span 
                key={index} 
                className="text-xs px-2.5 py-1 rounded-full bg-gray-100 dark:bg-gray-800 text-gray-700 dark:text-gray-300"
              >
                {feature}
              </span>
            ))}
            {tool.features.length > 3 && (
              <span className="text-xs px-2.5 py-1 rounded-full bg-gray-100 dark:bg-gray-800 text-gray-700 dark:text-gray-300">
                +{tool.features.length - 3} 更多
              </span>
            )}
          </div>
        </div>
        
        {/* 适用场景 */}
        <div className="mb-6">
          <h4 className="text-sm font-semibold mb-3 text-gray-500 dark:text-gray-400 uppercase tracking-wider">适用场景</h4>
          <div className="flex flex-wrap gap-2">
            {tool.适用场景.map((scene, index) => (
              <span 
                key={index} 
                className="text-xs px-2.5 py-1 rounded-full bg-blue-50 dark:bg-blue-900/20 text-blue-600 dark:text-blue-400"
              >
                {scene}
              </span>
            ))}
          </div>
        </div>
        
        {/* 操作按钮 */}
        <div className="flex justify-between items-center">
          <Button 
            href={`/tutorials/${tool.id}`} 
            className="text-blue-600 dark:text-blue-400 hover:text-blue-800 dark:hover:text-blue-300 font-medium transition-colors"
          >
            <i className="fa-book mr-1"></i> 查看教程
          </Button>
          <div className="flex gap-2">
            <Button 
              href={`/tools/${tool.id}`} 
              className="bg-gray-100 dark:bg-gray-800 hover:bg-gray-200 dark:hover:bg-gray-700 text-gray-700 dark:text-gray-300 px-3 py-1.5 rounded-lg text-sm transition-colors"
            >
              详情
            </Button>
            <a 
              href={tool.website} 
              target="_blank" 
              rel="noopener noreferrer"
              className="bg-blue-600 hover:bg-blue-700 text-white px-3 py-1.5 rounded-lg text-sm font-medium transition-colors flex items-center gap-1"
            >
              <i className="fa-external-link-alt"></i> 官网
            </a>
          </div>
        </div>
      </div>
    </motion.div>
  );
};