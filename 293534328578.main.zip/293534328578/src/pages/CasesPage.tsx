import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { useTheme } from '@/hooks/useTheme';
import { Button } from '@/components/Button';

// 案例类型定义
interface Case {
  id: string;
  title: string;
  description: string;
  tools: string[];
  category: string;
  difficulty: 'easy' | 'medium' | 'hard';
  scenario: string;
  image: string;
  beforeImage?: string;
  steps: number;
  author: string;
  authorAvatar: string;
  likes: number;
}

// 模拟案例数据
const mockCases: Case[] = [
  // 文本工具案例
  {
    id: 'chatgpt-content-creation',
    title: '使用ChatGPT生成高质量博客内容',
    description: '通过精心设计的提示词，让ChatGPT帮助你创建引人入胜的博客文章，提高内容创作效率。',
    tools: ['ChatGPT'],
    category: 'text',
    difficulty: 'easy',
    scenario: '内容创作',
    image: 'https://space.coze.cn/api/coze_space/gen_image?image_size=landscape_16_9&prompt=Blog%20content%20created%20with%20ChatGPT&sign=820facbcc9bd4bfc109e16271da5d695',
    beforeImage: 'https://space.coze.cn/api/coze_space/gen_image?image_size=landscape_16_9&prompt=Blank%20document%20before%20content%20creation&sign=014e51c21a0d7839b6a4c7622140c8e0',
    steps: 5,
    author: '张明',
    authorAvatar: 'https://space.coze.cn/api/coze_space/gen_image?image_size=square&prompt=Portrait%20of%20a%20content%20creator%20man&sign=c38799059c48457732ad342dc8951594',
    likes: 128
  },
  {
    id: 'claude-research-assistant',
    title: '使用Claude进行学术研究辅助',
    description: '利用Claude的长文本处理能力，快速分析研究论文，提取关键信息并生成文献综述。',
    tools: ['Claude'],
    category: 'text',
    difficulty: 'medium',
    scenario: '学术研究',
    image: 'https://space.coze.cn/api/coze_space/gen_image?image_size=landscape_16_9&prompt=Academic%20research%20assisted%20by%20Claude%20AI&sign=f1e402f944ec3b4c69cbddc1f73bc130',
    steps: 7,
    author: '李华',
    authorAvatar: 'https://space.coze.cn/api/coze_space/gen_image?image_size=square&prompt=Portrait%20of%20a%20researcher%20woman&sign=4e5df0ad352ee5c237f563ee72657133',
    likes: 95
  },
  {
    id: 'github-copilot-development',
    title: 'GitHub Copilot辅助前端开发实战',
    description: '学习如何利用GitHub Copilot加速React应用开发，提高代码质量和开发效率。',
    tools: ['GitHub Copilot'],
    category: 'text',
    difficulty: 'medium',
    scenario: '软件开发',
    image: 'https://space.coze.cn/api/coze_space/gen_image?image_size=landscape_16_9&prompt=Frontend%20development%20with%20GitHub%20Copilot&sign=150685871edeb339584c97e1de76fe91',
    steps: 8,
    author: '王强',
    authorAvatar: 'https://space.coze.cn/api/coze_space/gen_image?image_size=square&prompt=Portrait%20of%20a%20developer%20man&sign=2b8a827a84b347125903968b465879a3',
    likes: 156
  },
  
  // 绘图工具案例
  {
    id: 'midjourney-branding',
    title: '用Midjourney设计品牌标识和视觉系统',
    description: '从概念到成品，使用Midjourney创建独特的品牌标识、配色方案和视觉元素。',
    tools: ['Midjourney'],
    category: 'image',
    difficulty: 'medium',
    scenario: '品牌设计',
    image: 'https://space.coze.cn/api/coze_space/gen_image?image_size=landscape_16_9&prompt=Brand%20identity%20design%20with%20Midjourney&sign=c1bcb08c54768a44e01aa8b42f248098',
    beforeImage: 'https://space.coze.cn/api/coze_space/gen_image?image_size=landscape_16_9&prompt=Brand%20design%20concept%20sketch&sign=29acd640cf1f073f02c47ad66f2f75ca',
    steps: 9,
    author: '陈静',
    authorAvatar: 'https://space.coze.cn/api/coze_space/gen_image?image_size=square&prompt=Portrait%20of%20a%20graphic%20designer%20woman&sign=30043887b61e934bf3918ad320f5032c',
    likes: 210
  },
  {
    id: 'stable-diffusion-character',
    title: 'Stable Diffusion角色设计与一致性控制',
    description: '学习如何在Stable Diffusion中创建具有一致外观的角色设计，适用于游戏和动画项目。',
    tools: ['Stable Diffusion'],
    category: 'image',
    difficulty: 'hard',
    scenario: '角色设计',
    image: 'https://space.coze.cn/api/coze_space/gen_image?image_size=landscape_16_9&prompt=Character%20design%20with%20Stable%20Diffusion&sign=31774097df3681625b87d8151e633cbc',
    steps: 11,
    author: '刘阳',
    authorAvatar: 'https://space.coze.cn/api/coze_space/gen_image?image_size=square&prompt=Portrait%20of%20a%20game%20designer%20man&sign=fd7c87fac6271a1740c63e1a0f480c9a',
    likes: 178
  },
  {
    id: 'dalle3-illustration',
    title: 'DALL·E 3创建儿童绘本插图',
    description: '使用DALL·E 3的精确图像生成能力，为儿童绘本创建风格统一、富有想象力的插图。',
    tools: ['DALL·E 3'],
    category: 'image',
    difficulty: 'medium',
    scenario: '插画创作',
    image: 'https://space.coze.cn/api/coze_space/gen_image?image_size=landscape_16_9&prompt=Children%27s%20book%20illustrations%20by%20DALL-E%203&sign=2a3b62e50effddc20b72e5c66b647762',
    steps: 6,
    author: '林小',
    authorAvatar: 'https://space.coze.cn/api/coze_space/gen_image?image_size=square&prompt=Portrait%20of%20a%20children%27s%20book%20illustrator%20woman&sign=82d4a123c4dc92e65d5a0688855c65c1',
    likes: 145
  },
  
  // 视频工具案例
  {
    id: 'runwayml-video-editing',
    title: 'Runway ML AI视频编辑与特效制作',
    description: '学习如何使用Runway ML的AI工具进行视频剪辑、对象移除和特效添加，提升视频质量。',
    tools: ['Runway ML'],
    category: 'video',
    difficulty: 'medium',
    scenario: '视频制作',
    image: 'https://space.coze.cn/api/coze_space/gen_image?image_size=landscape_16_9&prompt=Video%20editing%20with%20Runway%20ML&sign=c90acf13492351e166901de40bbe40c1',
    beforeImage: 'https://space.coze.cn/api/coze_space/gen_image?image_size=landscape_16_9&prompt=Raw%20video%20footage%20before%20editing&sign=f7a096180e6b08fd0ae419c6850003d8',
    steps: 8,
    author: '赵伟',
    authorAvatar: 'https://space.coze.cn/api/coze_space/gen_image?image_size=square&prompt=Portrait%20of%20a%20video%20editor%20man&sign=4825800302ce9149275d75e7e8755869',
    likes: 167
  },
  {
    id: 'heygen-digital-human',
    title: 'HeyGen创建多语言虚拟主播视频',
    description: '使用HeyGen制作能说多种语言的虚拟主播视频，适用于内容营销和教育培训。',
    tools: ['HeyGen'],
    category: 'video',
    difficulty: 'medium',
    scenario: '内容营销',
    image: 'https://space.coze.cn/api/coze_space/gen_image?image_size=landscape_16_9&prompt=Digital%20human%20video%20created%20with%20HeyGen&sign=69b3d37fecbfb2eab31540a0d0e7a4fa',
    steps: 7,
    author: '吴梦',
    authorAvatar: 'https://space.coze.cn/api/coze_space/gen_image?image_size=square&prompt=Portrait%20of%20a%20content%20marketer%20woman&sign=9d20e26a5f37f4505f4922a5e0c04588',
    likes: 132
  },
  {
    id: 'pika-labs-animation',
    title: 'Pika Labs文本到视频创意动画制作',
    description: '将静态图像和文本提示转换为引人入胜的动画内容，用于社交媒体和数字营销。',
    tools: ['Pika Labs'],
    category: 'video',
    difficulty: 'easy',
    scenario: '动画创作',
    image: 'https://space.coze.cn/api/coze_space/gen_image?image_size=landscape_16_9&prompt=Animation%20created%20with%20Pika%20Labs&sign=578eadd64ea149d03d2e902989426bc3',
    steps: 5,
    author: '孙艺',
    authorAvatar: 'https://space.coze.cn/api/coze_space/gen_image?image_size=square&prompt=Portrait%20of%20a%20digital%20artist%20woman&sign=1ec3b6c4f1f2f75c6c5da7e10cf9d37d',
    likes: 118
  }
];

const CasesPage: React.FC = () => {
  const { theme } = useTheme();
  const [selectedCategory, setSelectedCategory] = useState('all');
  const [selectedDifficulty, setSelectedDifficulty] = useState('all');
  const [selectedScenario, setSelectedScenario] = useState('all');
  const [filteredCases, setFilteredCases] = useState<Case[]>(mockCases);
  const [searchTerm, setSearchTerm] = useState('');
  
  // 过滤案例
  React.useEffect(() => {
    let result = mockCases;
    
    // 按分类过滤
    if (selectedCategory !== 'all') {
      result = result.filter(caseItem => caseItem.category === selectedCategory);
    }
    
    // 按难度级别过滤
    if (selectedDifficulty !== 'all') {
      result = result.filter(caseItem => caseItem.difficulty === selectedDifficulty);
    }
    
    // 按应用场景过滤
    if (selectedScenario !== 'all') {
      result = result.filter(caseItem => caseItem.scenario === selectedScenario);
    }
    
    // 按搜索词过滤
    if (searchTerm) {
      const term = searchTerm.toLowerCase();
      result = result.filter(caseItem => 
        caseItem.title.toLowerCase().includes(term) || 
        caseItem.description.toLowerCase().includes(term) ||
        caseItem.tools.some(tool => tool.toLowerCase().includes(term)) ||
        caseItem.scenario.toLowerCase().includes(term)
      );
    }
    
    setFilteredCases(result);
  }, [selectedCategory, selectedDifficulty, selectedScenario, searchTerm]);
  
  // 筛选选项
  const categories = [
    { id: 'all', name: '全部工具', icon: 'fa-th-large' },
    { id: 'text', name: '文本工具', icon: 'fa-file-alt' },
    { id: 'image', name: '绘图工具', icon: 'fa-image' },
    { id: 'video', name: '视频工具', icon: 'fa-video' }
  ];
  
  const difficulties = [
    { id: 'all', name: '全部难度' },
    { id: 'easy', name: '简单', icon: 'fa-check-circle' },
    { id: 'medium', name: '中等', icon: 'fa-exclamation-circle' },
    { id: 'hard', name: '困难', icon: 'fa-times-circle' }
  ];
  
  const scenarios = [
    { id: 'all', name: '全部场景' },
    { id: '内容创作', name: '内容创作' },
    { id: '学术研究', name: '学术研究' },
    { id: '软件开发', name: '软件开发' },
    { id: '品牌设计', name: '品牌设计' },
    { id: '角色设计', name: '角色设计' },
    { id: '插画创作', name: '插画创作' },
    { id: '视频制作', name: '视频制作' },
    { id: '内容营销', name: '内容营销' },
    { id: '动画创作', name: '动画创作' }
  ];
  
  // 获取难度对应的标签样式
  const getDifficultyBadge = (difficulty: string) => {
    switch(difficulty) {
      case 'easy':
        return { text: '简单', color: 'bg-green-100 dark:bg-green-900/50 text-green-600 dark:text-green-400' };
      case 'medium':
        return { text: '中等', color: 'bg-yellow-100 dark:bg-yellow-900/50 text-yellow-600 dark:text-yellow-400' };
      case 'hard':
        return { text: '困难', color: 'bg-red-100 dark:bg-red-900/50 text-red-600 dark:text-red-400' };
      default:
        return { text: '全部', color: 'bg-gray-100 dark:bg-gray-800 text-gray-600 dark:text-gray-400' };
    }
  };
  
  // 动画变体
  const fadeIn = {
    hidden: { opacity: 0, y: 20 },
    visible: { opacity: 1, y: 0, transition: { duration: 0.6 } }
  };
  
  const staggerContainer = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.1
      }
    }
  };
  
  return (
    <div className="py-24 bg-white dark:bg-gray-900 min-h-screen">
      <div className="container mx-auto px-4">
        {/* 页面标题 */}
        <motion.div 
          className="max-w-3xl mx-auto text-center mb-16"
          initial="hidden"
          animate="visible"
          variants={fadeIn}
        >
          <h1 className="text-4xl md:text-5xl font-bold mb-6 text-gray-800 dark:text-white">
            AI 工具应用案例
          </h1>
          <p className="text-xl text-gray-600 dark:text-gray-400">
            探索真实的AI工具应用场景，获取灵感并学习实用技巧
          </p>
        </motion.div>
        
        {/* 搜索框 */}
        <motion.div 
          className="max-w-2xl mx-auto mb-12"
          initial="hidden"
          animate="visible"
          variants={fadeIn}
          transition={{ delay: 0.2 }}
        >
          <div className="relative">
            <input
              type="text"
              placeholder="搜索案例、工具或应用场景..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full py-4 px-6 pr-12 rounded-xl border border-gray-200 dark:border-gray-700 bg-gray-50 dark:bg-gray-800 focus:outline-none focus:ring-2 focus:ring-blue-500 dark:focus:ring-blue-600 text-gray-800 dark:text-white"
            />
            <button 
              className="absolute right-4 top-1/2 transform -translate-y-1/2 text-gray-400 hover:text-gray-600 dark:hover:text-gray-300"
              onClick={() => setSearchTerm('')}
              aria-label="清除搜索"
            >
              <i className="fa-times-circle text-xl"></i>
            </button>
          </div>
        </motion.div>
        
        {/* 筛选器 */}
        <div className="mb-12">
          <div className="flex flex-col md:flex-row gap-6">
            {/* 工具分类筛选 */}
            <motion.div 
              className="flex-1"
              initial="hidden"
              animate="visible"
              variants={staggerContainer}
            >
              <h3 className="text-lg font-semibold mb-4 text-gray-800 dark:text-white">工具类型</h3>
              <div className="flex flex-wrap gap-3">
                {categories.map((category) => (
                  <motion.button
                    key={category.id}
                    variants={fadeIn}
                    whileHover={{ scale: 1.05 }}
                    whileTap={{ scale: 0.95 }}
                    onClick={() => setSelectedCategory(category.id)}
                    className={`flex items-center gap-2 px-4 py-2 rounded-full transition-all ${
                      selectedCategory === category.id 
                        ? 'bg-blue-600 text-white shadow-md' 
                        : 'bg-gray-100 dark:bg-gray-800 text-gray-700 dark:text-gray-300 hover:bg-gray-200 dark:hover:bg-gray-700'
                    }`}
                  >
                    <i className={`fa-solid ${category.icon}`}></i>
                    <span>{category.name}</span>
                  </motion.button>
                ))}
              </div>
            </motion.div>
            
            {/* 难度级别筛选 */}
            <motion.div 
              className="flex-1"
              initial="hidden"
              animate="visible"
              variants={staggerContainer}
              transition={{ delay: 0.1 }}
            >
              <h3 className="text-lg font-semibold mb-4 text-gray-800 dark:text-white">难度级别</h3>
              <div className="flex flex-wrap gap-3">
                {difficulties.map((difficulty) => (
                  <motion.button
                    key={difficulty.id}
                    variants={fadeIn}
                    whileHover={{ scale: 1.05 }}
                    whileTap={{ scale: 0.95 }}
                    onClick={() => setSelectedDifficulty(difficulty.id)}
                    className={`flex items-center gap-2 px-4 py-2 rounded-full transition-all ${
                      selectedDifficulty === difficulty.id 
                        ? 'bg-blue-600 text-white shadow-md' 
                        : 'bg-gray-100 dark:bg-gray-800 text-gray-700 dark:text-gray-300 hover:bg-gray-200 dark:hover:bg-gray-700'
                    }`}
                  >
                    {difficulty.icon && <i className={`fa-solid ${difficulty.icon}`}></i>}
                    <span>{difficulty.name}</span>
                  </motion.button>
                ))}
              </div>
            </motion.div>
            
            {/* 应用场景筛选 */}
            <motion.div 
              className="flex-1"
              initial="hidden"
              animate="visible"
              variants={staggerContainer}
              transition={{ delay: 0.2 }}
            >
              <h3 className="text-lg font-semibold mb-4 text-gray-800 dark:text-white">应用场景</h3>
              <div className="flex flex-wrap gap-3">
                {scenarios.slice(0, 5).map((scenario) => (
                  <motion.button
                    key={scenario.id}
                    variants={fadeIn}
                    whileHover={{ scale: 1.05 }}
                    whileTap={{ scale: 0.95 }}
                    onClick={() => setSelectedScenario(scenario.id)}
                    className={`px-4 py-2 rounded-full transition-all text-sm ${
                      selectedScenario === scenario.id 
                        ? 'bg-blue-600 text-white shadow-md' 
                        : 'bg-gray-100 dark:bg-gray-800 text-gray-700 dark:text-gray-300 hover:bg-gray-200 dark:hover:bg-gray-700'
                    }`}
                  >
                    {scenario.name}
                  </motion.button>
                ))}
                {scenarios.length > 5 && (
                  <motion.div 
                    className="relative group"
                    variants={fadeIn}
                  >
                    <button className="px-4 py-2 rounded-full transition-all text-sm bg-gray-100 dark:bg-gray-800 text-gray-700 dark:text-gray-300 hover:bg-gray-200 dark:hover:bg-gray-700">
                      更多 <i className="fa-chevron-down ml-1 text-xs"></i>
                    </button>
                    <div className="absolute left-0 mt-2 w-48 rounded-xl bg-white dark:bg-gray-900 shadow-lg border border-gray-200 dark:border-gray-700 opacity-0 invisible group-hover:opacity-100 group-hover:visible transition-all z-10">
                      {scenarios.slice(5).map((scenario) => (
                        <button
                          key={scenario.id}
                          onClick={() => setSelectedScenario(scenario.id)}
                          className={`w-full text-left px-4 py-2 text-sm transition-colors ${
                            selectedScenario === scenario.id 
                              ? 'bg-blue-50 dark:bg-blue-900/30 text-blue-600 dark:text-blue-400' 
                              : 'text-gray-700 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-800'
                          }`}
                        >
                          {scenario.name}
                        </button>
                      ))}
                    </div>
                  </motion.div>
                )}
              </div>
            </motion.div>
          </div>
        </div>
        
        {/* 案例列表 */}
        <motion.div
          className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8"
          initial="hidden"
          animate="visible"
          variants={staggerContainer}
        >
          {filteredCases.map((caseItem) => {
            const difficultyBadge = getDifficultyBadge(caseItem.difficulty);
            return (
              <motion.div 
                key={caseItem.id}
                className="bg-white dark:bg-gray-900 rounded-xl overflow-hidden shadow-lg border border-gray-200 dark:border-gray-700"
                variants={fadeIn}
                whileHover={{ y: -5, transition: { duration: 0.2 } }}
              >
                {/* 案例图片 */}
                <div className="h-48 relative overflow-hidden">
                  <img 
                    src={caseItem.image} 
                    alt={caseItem.title} 
                    className="w-full h-full object-cover transition-transform duration-700 hover:scale-110"
                    loading="lazy"
                  />
                  {caseItem.beforeImage && (
                    <div className="absolute inset-0 bg-gradient-to-t from-black/50 via-transparent to-transparent flex items-end">
                      <div className="p-4 w-full">
                        <button className="bg-white/20 backdrop-blur-sm text-white text-xs px-3 py-1.5 rounded-full hover:bg-white/30 transition-colors">
                          <i className="fa-exchange-alt mr-1"></i> 查看前后对比
                        </button>
                      </div>
                    </div>
                  )}
                </div>
                
                {/* 案例信息 */}
                <div className="p-6">
                  {/* 标签 */}
                  <div className="flex flex-wrap gap-2 mb-3">
                    <span className={`text-xs font-medium px-2.5 py-1 rounded-full ${difficultyBadge.color}`}>
                      {difficultyBadge.text}
                    </span>
                    <span className={`text-xs font-medium px-2.5 py-1 rounded-full ${
                      caseItem.category === 'text' 
                        ? 'bg-blue-100 dark:bg-blue-900/50 text-blue-600 dark:text-blue-400' 
                        : caseItem.category === 'image'
                        ? 'bg-purple-100 dark:bg-purple-900/50 text-purple-600 dark:text-purple-400'
                        : 'bg-red-100 dark:bg-red-900/50 text-red-600 dark:text-red-400'
                    }`}>
                      {caseItem.category === 'text' ? '文本工具' : 
                       caseItem.category === 'image' ? '绘图工具' : '视频工具'}
                    </span>
                    <span className="text-xs font-medium px-2.5 py-1 rounded-full bg-gray-100 dark:bg-gray-800 text-gray-600 dark:text-gray-400">
                      {caseItem.scenario}
                    </span>
                  </div>
                  
                  {/* 标题 */}
                  <h3 className="text-xl font-bold mb-3 text-gray-800 dark:text-white line-clamp-2">
                    {caseItem.title}
                  </h3>
                  
                  {/* 描述 */}
                  <p className="text-gray-600 dark:text-gray-400 mb-4 line-clamp-2">
                    {caseItem.description}
                  </p>
                  
                  {/* 使用工具 */}
                  <div className="mb-5">
                    <h4 className="text-xs font-semibold uppercase tracking-wider text-gray-500 dark:text-gray-400 mb-2">使用工具</h4>
                    <div className="flex flex-wrap gap-2">
                      {caseItem.tools.map((tool, index) => (
                        <span 
                          key={index} 
                          className="text-xs px-2.5 py-1 rounded-full bg-blue-50 dark:bg-blue-900/20 text-blue-600 dark:text-blue-400"
                        >
                          {tool}
                        </span>
                      ))}
                    </div>
                  </div>
                  
                  {/* 作者和互动 */}
                  <div className="flex justify-between items-center mb-5">
                    <div className="flex items-center">
                      <img 
                        src={caseItem.authorAvatar} 
                        alt={caseItem.author} 
                        className="w-8 h-8 rounded-full object-cover mr-2"
                      />
                      <span className="text-sm text-gray-600 dark:text-gray-400">{caseItem.author}</span>
                    </div>
                    <div className="flex items-center text-gray-500 dark:text-gray-400 text-sm">
                      <i className="fa-heart mr-1"></i>
                      <span>{caseItem.likes}</span>
                    </div>
                  </div>
                  
                  {/* 操作按钮 */}
                  <div className="flex gap-2">
                    <Button 
                      href={`/cases/${caseItem.id}`}
                      className="flex-1 bg-blue-600 hover:bg-blue-700 text-white py-2 rounded-lg font-medium transition-all"
                    >
                      查看详情
                    </Button>
                    <button className="p-2 rounded-lg border border-gray-200 dark:border-gray-700 text-gray-600 dark:text-gray-400 hover:bg-gray-100 dark:hover:bg-gray-800 transition-colors">
                      <i className="fa-bookmark"></i>
                    </button>
                  </div>
                </div>
              </motion.div>
            );
          })}
        </motion.div>
        
        {/* 用户案例投稿入口 */}
        <motion.div 
          className="mt-16 p-8 rounded-2xl bg-gradient-to-r from-blue-50 to-indigo-50 dark:from-blue-900/20 dark:to-indigo-900/20 text-center"
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true }}
          variants={fadeIn}
        >
          <h2 className="text-2xl md:text-3xl font-bold mb-4 text-gray-800 dark:text-white">
            分享你的AI工具使用案例
          </h2>
          <p className="text-lg text-gray-600 dark:text-gray-400 mb-8 max-w-2xl mx-auto">
            你有使用AI工具的精彩案例吗？分享给社区，帮助更多新手学习和成长
          </p>
          <Button 
            className="bg-blue-600 hover:bg-blue-700 text-white px-8 py-3 rounded-lg text-lg font-medium transition-all transform hover:scale-105"
          >
            <i className="fa-upload mr-2"></i> 提交案例
          </Button>
        </motion.div>
        
        {/* 空状态 */}
        {filteredCases.length === 0 && (
          <motion.div 
            className="text-center py-16 max-w-xl mx-auto"
            initial="hidden"
            animate="visible"
            variants={fadeIn}
          >
            <div className="w-24 h-24 mx-auto mb-6 rounded-full bg-gray-100 dark:bg-gray-800 flex items-center justify-center">
              <i className="fa-lightbulb text-gray-400 text-4xl"></i>
            </div>
            <h3 className="text-xl font-bold mb-2 text-gray-800 dark:text-white">没有找到匹配的案例</h3>
            <p className="text-gray-600 dark:text-gray-400 mb-6">尝试使用不同的搜索词或筛选条件</p>
            <Button 
              onClick={() => {
                setSearchTerm('');
                setSelectedCategory('all');
                setSelectedDifficulty('all');
                setSelectedScenario('all');
              }}
              className="bg-blue-600 hover:bg-blue-700 text-white px-6 py-2 rounded-lg transition-all"
            >
              查看全部案例
            </Button>
          </motion.div>
        )}
      </div>
    </div>
  );
};

export default CasesPage;