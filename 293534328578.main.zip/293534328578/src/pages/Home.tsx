import React from 'react';
import { motion } from 'framer-motion';
import { useTheme } from '@/hooks/useTheme';
import { Button } from '@/components/Button';

export default function Home() {
  const { theme, toggleTheme } = useTheme();
  
  // 动画变体
  const fadeIn = {
    hidden: { opacity: 0, y: 20 },
    visible: { opacity: 1, y: 0, transition: { duration: 0.6 } }
  };
  
  const staggerContainer = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.2
      }
    }
  };

  return (
    <div className="min-h-screen">
      {/* Hero区域 */}
      <section className="relative overflow-hidden bg-gradient-to-br from-blue-50 to-indigo-50 dark:from-gray-900 dark:to-blue-900">
        <div className="container mx-auto px-4 py-20 md:py-32 relative z-10">
          <motion.div 
            className="max-w-3xl mx-auto text-center"
            initial="hidden"
            animate="visible"
            variants={staggerContainer}
          >
            <motion.h1 
              className="text-4xl md:text-6xl font-bold mb-6 bg-clip-text text-transparent bg-gradient-to-r from-blue-600 to-indigo-600 dark:from-blue-400 dark:to-indigo-400"
              variants={fadeIn}
            >
              轻松入门 AI 工具世界
            </motion.h1>
            <motion.p 
              className="text-xl md:text-2xl mb-10 text-gray-600 dark:text-gray-300"
              variants={fadeIn}
            >
              为新手量身打造的 AI 工具学习平台，助你快速掌握前沿技术
            </motion.p>
            <motion.div 
              className="flex flex-col sm:flex-row justify-center gap-4"
              variants={fadeIn}
            >
              <Button href="/tools" className="bg-blue-600 hover:bg-blue-700 text-white px-8 py-3 rounded-lg text-lg font-medium transition-all transform hover:scale-105">
                浏览 AI 工具
              </Button>
              <Button href="/tutorials" className="bg-white dark:bg-gray-800 hover:bg-gray-100 dark:hover:bg-gray-700 text-blue-600 dark:text-blue-400 px-8 py-3 rounded-lg text-lg font-medium border border-blue-200 dark:border-gray-700 transition-all transform hover:scale-105">
                查看教程
              </Button>
            </motion.div>
          </motion.div>
          
          {/* 装饰图形 */}
          <motion.div 
            className="absolute top-1/4 left-10 w-64 h-64 bg-blue-200 dark:bg-blue-900/30 rounded-full filter blur-3xl opacity-40"
            animate={{ 
              scale: [1, 1.2, 1],
              opacity: [0.4, 0.6, 0.4] 
            }}
            transition={{ 
              duration: 8,
              repeat: Infinity,
              repeatType: "reverse" 
            }}
          />
          <motion.div 
            className="absolute bottom-1/4 right-10 w-80 h-80 bg-indigo-200 dark:bg-indigo-900/30 rounded-full filter blur-3xl opacity-40"
            animate={{ 
              scale: [1, 1.3, 1],
              opacity: [0.4, 0.5, 0.4] 
            }}
            transition={{ 
              duration: 10,
              repeat: Infinity,
              repeatType: "reverse" 
            }}
          />
        </div>
      </section>
      
      {/* 特色功能 */}
      <section className="py-20 bg-white dark:bg-gray-900">
        <div className="container mx-auto px-4">
          <motion.div 
            className="max-w-3xl mx-auto text-center mb-16"
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true }}
            variants={fadeIn}
          >
            <h2 className="text-3xl md:text-4xl font-bold mb-6 text-gray-800 dark:text-white">为什么选择我们的平台</h2>
            <p className="text-lg text-gray-600 dark:text-gray-400">专为AI工具新手设计的学习体验，让复杂的技术变得简单易用</p>
          </motion.div>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {[
              {
                title: "全面的工具分类",
                description: "按功能分类整理AI文本、绘图、视频等工具，方便查找适合自己的AI助手",
                icon: "fa-magic"
              },
              {
                title: "新手友好教程",
                description: "从入门到精通的详细教程，包含图文指南和实用技巧，助你快速上手",
                icon: "fa-book-open"
              },
              {
                title: "真实案例展示",
                description: "丰富的应用案例和灵感库，了解AI工具在不同场景下的实际应用",
                icon: "fa-lightbulb"
              }
            ].map((feature, index) => (
              <motion.div
                key={index}
                className="bg-gray-50 dark:bg-gray-800 rounded-xl p-8 shadow-lg hover:shadow-xl transition-shadow border border-gray-100 dark:border-gray-700"
                initial="hidden"
                whileInView="visible"
                viewport={{ once: true }}
                variants={{
                  hidden: { opacity: 0, y: 20 },
                  visible: { 
                    opacity: 1, 
                    y: 0, 
                    transition: { 
                      duration: 0.5,
                      delay: index * 0.1 
                    } 
                  }
                }}
                whileHover={{ y: -5, transition: { duration: 0.2 } }}
              >
                <div className="w-14 h-14 bg-blue-100 dark:bg-blue-900/50 rounded-full flex items-center justify-center mb-6">
                  <i className={`fa-solid ${feature.icon} text-blue-600 dark:text-blue-400 text-2xl`}></i>
                </div>
                <h3 className="text-xl font-bold mb-4 text-gray-800 dark:text-white">{feature.title}</h3>
                <p className="text-gray-600 dark:text-gray-400">{feature.description}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>
      
      {/* 热门工具预览 */}
      <section className="py-20 bg-gray-50 dark:bg-gray-800">
        <div className="container mx-auto px-4">
          <div className="flex flex-col md:flex-row justify-between items-center mb-12">
            <motion.div 
              className="mb-6 md:mb-0"
              initial="hidden"
              whileInView="visible"
              viewport={{ once: true }}
              variants={fadeIn}
            >
              <h2 className="text-3xl md:text-4xl font-bold mb-4 text-gray-800 dark:text-white">热门 AI 工具</h2>
              <p className="text-lg text-gray-600 dark:text-gray-400">探索最受欢迎的AI工具，提升工作效率和创造力</p>
            </motion.div>
            <motion.div
              initial="hidden"
              whileInView="visible"
              viewport={{ once: true }}
              variants={fadeIn}
            >
              <Button href="/tools" className="bg-blue-600 hover:bg-blue-700 text-white px-6 py-2 rounded-lg transition-all">
                查看全部 <i className="fa-arrow-right ml-2"></i>
              </Button>
            </motion.div>
          </div>
          
          <motion.div 
            className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-8"
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true }}
            variants={staggerContainer}
          >
            {[
              {
                name: "ChatGPT",
                category: "AI文本工具",
                description: "强大的对话式AI助手，能够生成文本、回答问题、协助创作",
                image: "https://space.coze.cn/api/coze_space/gen_image?image_size=square&prompt=ChatGPT%20interface%20showing%20AI%20conversation&sign=63d036dc03ca7555bd7f21cb4a5cf1d3",
                price: "免费/付费"
              },
              {
                name: "Midjourney",
                category: "AI绘图工具",
                description: "通过文本提示生成高质量图像，激发无限创意可能性",
                image: "https://space.coze.cn/api/coze_space/gen_image?image_size=square&prompt=AI%20generated%20artwork%20created%20by%20Midjourney&sign=861c61b5ee307b8cfb098b487cbe6505",
                price: "付费"
              },
              {
                name: "Runway ML",
                category: "AI视频工具",
                description: "AI驱动的视频编辑平台，提供智能剪辑、特效和内容生成功能",
                image: "https://space.coze.cn/api/coze_space/gen_image?image_size=square&prompt=Runway%20ML%20video%20editing%20interface&sign=a57598760622581ef3d7e9665a043392",
                price: "免费/付费"
              }
            ].map((tool, index) => (
              <motion.div 
                key={index}
                className="bg-white dark:bg-gray-900 rounded-xl overflow-hidden shadow-md hover:shadow-xl transition-all border border-gray-200 dark:border-gray-700"
                variants={fadeIn}
                whileHover={{ y: -5, transition: { duration: 0.2 } }}
              >
                <div className="h-48 overflow-hidden">
                  <img 
                    src={tool.image} 
                    alt={tool.name} 
                    className="w-full h-full object-cover transition-transform duration-500 hover:scale-110"
                  />
                </div>
                <div className="p-6">
                  <div className="flex justify-between items-center mb-3">
                    <span className="text-sm font-medium px-3 py-1 bg-blue-100 dark:bg-blue-900/50 text-blue-600 dark:text-blue-400 rounded-full">
                      {tool.category}
                    </span>
                    <span className="text-sm font-medium text-gray-500 dark:text-gray-400">
                      {tool.price}
                    </span>
                  </div>
                  <h3 className="text-xl font-bold mb-2 text-gray-800 dark:text-white">{tool.name}</h3>
                  <p className="text-gray-600 dark:text-gray-400 mb-4">{tool.description}</p>
                  <div className="flex justify-between items-center">
                    <Button 
                      href={`/tools#${tool.name.toLowerCase()}`} 
                      className="text-blue-600 dark:text-blue-400 hover:text-blue-800 dark:hover:text-blue-300 transition-colors"
                    >
                      了解详情 <i className="fa-angle-right ml-1"></i>
                    </Button>
                    <Button 
                      href={`/tutorials/${tool.name.toLowerCase()}`}
                      className="px-3 py-1 bg-gray-100 dark:bg-gray-700 hover:bg-gray-200 dark:hover:bg-gray-600 rounded-lg text-sm transition-colors"
                    >
                      <i className="fa-book mr-1"></i> 教程
                    </Button>
                  </div>
                </div>
              </motion.div>
            ))}
          </motion.div>
        </div>
      </section>
      
      {/* 学习路径图 */}
      <section className="py-20 bg-white dark:bg-gray-900">
        <div className="container mx-auto px-4">
          <motion.div 
            className="max-w-3xl mx-auto text-center mb-16"
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true }}
            variants={fadeIn}
          >
            <h2 className="text-3xl md:text-4xl font-bold mb-4 text-gray-800 dark:text-white">AI 工具学习路径</h2>
            <p className="text-lg text-gray-600 dark:text-gray-400">从新手到高手，一步步掌握AI工具的使用技巧</p>
          </motion.div>
          
          <div className="relative max-w-4xl mx-auto">
            {/* 连接线 */}
            <div className="hidden md:block absolute left-1/2 top-0 bottom-0 w-1 bg-blue-200 dark:bg-blue-800 transform -translate-x-1/2 z-0"></div>
            
            {[
              {
                stage: "新手阶段",
                title: "基础入门",
                description: "了解AI工具的基本概念，掌握常用工具的注册和基础操作",
                tools: "ChatGPT、Notion AI、DALL·E"
              },
              {
                stage: "进阶阶段",
                title: "熟练应用",
                description: "深入学习各工具的高级功能，掌握提示词工程和效率提升技巧",
                tools: "Midjourney、Stable Diffusion、Runway ML"
              },
              {
                stage: "高手阶段",
                title: "创新整合",
                description: "将多种AI工具组合使用，创造复杂项目，实现工作流程自动化",
                tools: "Claude、LangChain、自定义AI工作流"
              }
            ].map((step, index) => (
              <motion.div 
                key={index}
                className="relative z-10 mb-16"
                initial="hidden"
                whileInView="visible"
                viewport={{ once: true }}
                variants={{
                  hidden: { opacity: 0, x: index % 2 === 0 ? -20 : 20 },
                  visible: { 
                    opacity: 1, 
                    x: 0, 
                    transition: { 
                      duration: 0.5,
                      delay: index * 0.2 
                    } 
                  }
                }}
              >
                <div className="flex flex-col md:flex-row items-center">
                  <div className={`md:w-1/2 ${index % 2 === 0 ? 'md:pr-12 md:text-right' : 'md:pl-12'} order-2 md:order-1`}>
                    <div className="p-6 bg-gray-50 dark:bg-gray-800 rounded-xl shadow-md border border-gray-100 dark:border-gray-700">
                      <span className="inline-block px-3 py-1 bg-blue-100 dark:bg-blue-900/50 text-blue-600 dark:text-blue-400 text-sm font-medium rounded-full mb-3">
                        {step.stage}
                      </span>
                      <h3 className="text-xl font-bold mb-3 text-gray-800 dark:text-white">{step.title}</h3>
                      <p className="text-gray-600 dark:text-gray-400 mb-4">{step.description}</p>
                      <div className="text-sm text-gray-500 dark:text-gray-400">
                        <span className="font-medium text-gray-700 dark:text-gray-300">推荐工具：</span> {step.tools}
                      </div>
                    </div>
                  </div>
                  
                  <div className="w-12 h-12 rounded-full bg-blue-600 dark:bg-blue-500 flex items-center justify-center text-white font-bold text-xl mb-6 md:mb-0 order-1 md:order-2">
                    {index + 1}
                  </div>
                  
                  {index % 2 === 1 && <div className="md:w-1/2 order-2"></div>}
                </div>
              </motion.div>
            ))}
          </div>
          
          <motion.div 
            className="text-center mt-12"
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true }}
            variants={fadeIn}
          >
            <Button href="/tutorials" className="bg-blue-600 hover:bg-blue-700 text-white px-6 py-2 rounded-lg transition-all">
              开始学习之旅
            </Button>
          </motion.div>
        </div>
      </section>
      
      {/* 用户评价 */}
      <section className="py-20 bg-gradient-to-br from-blue-50 to-indigo-50 dark:from-gray-900 dark:to-blue-900">
        <div className="container mx-auto px-4">
          <motion.div 
            className="max-w-3xl mx-auto text-center mb-16"
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true }}
            variants={fadeIn}
          >
            <h2 className="text-3xl md:text-4xl font-bold mb-4 text-gray-800 dark:text-white">用户的声音</h2>
            <p className="text-lg text-gray-600 dark:text-gray-400">看看其他新手如何通过我们的平台学习AI工具</p>
          </motion.div>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {[
              {
                name: "张明",
                role: "内容创作者",
                comment: "作为一个完全的AI新手，这个平台帮助我快速上手了ChatGPT和Midjourney，现在我的创作效率提高了10倍！",
                avatar: "https://space.coze.cn/api/coze_space/gen_image?image_size=square&prompt=Portrait%20of%20a%20content%20creator%20man&sign=c38799059c48457732ad342dc8951594"
              },
              {
                name: "李华",
                role: "市场营销专员",
                comment: "教程非常详细，一步一步跟着做就能轻松掌握。现在我能用AI工具生成营销文案和创意素材了。",
                avatar: "https://space.coze.cn/api/coze_space/gen_image?image_size=square&prompt=Portrait%20of%20a%20marketing%20specialist%20woman&sign=6ba7f93faefd5b853c38d72c00cafd55"
              },
              {
                name: "王强",
                role: "自由设计师",
                comment: "案例展示给了我很多灵感，学习路径图也很清晰，让我能够系统性地学习各种AI设计工具。",
                avatar: "https://space.coze.cn/api/coze_space/gen_image?image_size=square&prompt=Portrait%20of%20a%20freelance%20designer%20man&sign=a51565ca87412332b95dd9699b9e6049"
              }
            ].map((testimonial, index) => (
              <motion.div 
                key={index}
                className="bg-white dark:bg-gray-900 p-8 rounded-xl shadow-lg border border-gray-100 dark:border-gray-700"
                initial="hidden"
                whileInView="visible"
                viewport={{ once: true }}
                variants={{
                  hidden: { opacity: 0, y: 20 },
                  visible: { 
                    opacity: 1, 
                    y: 0, 
                    transition: { 
                      duration: 0.5,
                      delay: index * 0.1 
                    } 
                  }
                }}
                whileHover={{ y: -5, transition: { duration: 0.2 } }}
              >
                <div className="flex items-center mb-6">
                  <img 
                    src={testimonial.avatar} 
                    alt={testimonial.name} 
                    className="w-14 h-14 rounded-full object-cover mr-4"
                  />
                  <div>
                    <h4 className="font-bold text-gray-800 dark:text-white">{testimonial.name}</h4>
                    <p className="text-gray-600 dark:text-gray-400 text-sm">{testimonial.role}</p>
                  </div>
                </div>
                <p className="text-gray-700 dark:text-gray-300 italic">"{testimonial.comment}"</p>
                <div className="mt-6 text-yellow-400">
                  {[...Array(5)].map((_, i) => (
                    <i key={i} className="fa-solid fa-star"></i>
                  ))}
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>
      
      {/* 行动召唤 */}
      <section className="py-20 bg-blue-600 dark:bg-blue-700 text-white">
        <div className="container mx-auto px-4">
          <motion.div 
            className="max-w-3xl mx-auto text-center"
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true }}
            variants={staggerContainer}
          >
            <motion.h2 
              className="text-3xl md:text-4xl font-bold mb-6"
              variants={fadeIn}
            >
              开始你的AI学习之旅吧！
            </motion.h2>
            <motion.p 
              className="text-xl mb-10 text-blue-100"
              variants={fadeIn}
            >
              无论你是完全的新手还是想提升AI技能的学习者，我们都能帮助你实现目标
            </motion.p>
            <motion.div 
              className="flex flex-col sm:flex-row justify-center gap-4"
              variants={fadeIn}
            >
              <Button href="/tools" className="bg-white text-blue-600 hover:bg-blue-50 px-8 py-3 rounded-lg text-lg font-medium transition-all transform hover:scale-105">
                探索工具
              </Button>
              <Button href="/tutorials" className="bg-transparent border-2 border-white hover:bg-white/10 text-white px-8 py-3 rounded-lg text-lg font-medium transition-all transform hover:scale-105">
                浏览教程
              </Button>
            </motion.div>
          </motion.div>
        </div>
      </section>
    </div>
  );
}