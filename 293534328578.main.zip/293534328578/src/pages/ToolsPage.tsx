import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { useTheme } from '@/hooks/useTheme';
import { Button } from '@/components/Button';
import { ToolCard } from '@/components/ToolCard';

// 工具类型定义
interface Tool {
  id: string;
  name: string;
  category: string;
  description: string;
  features: string[];
  price: string;
 适用场景: string[];
  website: string;
  image: string;
}

// 工具分类
const categories = [
  { id: 'all', name: '全部工具', icon: 'fa-th-large' },
  { id: 'text', name: 'AI文本工具', icon: 'fa-file-alt' },
  { id: 'image', name: 'AI绘图工具', icon: 'fa-image' },
  { id: 'video', name: 'AI视频工具', icon: 'fa-video' }
];

// 模拟工具数据
const mockTools: Tool[] = [
  // AI文本工具
  {
    id: 'chatgpt',
    name: 'ChatGPT',
    category: 'text',
    description: '由OpenAI开发的强大对话式AI助手，能够生成文本、回答问题、协助创作。',
    features: ['自然语言对话', '内容创作', '代码生成', '问题解答', '学习辅助'],
    price: '免费/付费',
    适用场景: ['内容创作', '学习研究', '日常助手', '编程辅助'],
    website: 'https://chat.openai.com',
    image: 'https://space.coze.cn/api/coze_space/gen_image?image_size=square&prompt=ChatGPT%20interface%20showing%20AI%20conversation&sign=63d036dc03ca7555bd7f21cb4a5cf1d3'
  },
  {
    id: 'notion-ai',
    name: 'Notion AI',
    category: 'text',
    description: '集成在Notion中的AI助手，帮助用户撰写、编辑和优化文本内容。',
    features: ['文本生成', '内容总结', '语法检查', '风格调整', '想法扩展'],
    price: '付费',
    适用场景: ['笔记整理', '内容创作', '文档编辑', '项目管理'],
    website: 'https://www.notion.so/ai',
    image: 'https://space.coze.cn/api/coze_space/gen_image?image_size=square&prompt=Notion%20AI%20interface%20showing%20AI%20assistant%20features&sign=1866c82fe7f4d5fd98b7d4fb183b4104'
  },
  {
    id: 'claude',
    name: 'Claude',
    category: 'text',
    description: '由Anthropic开发的AI助手，专注于安全性和长篇文本处理能力。',
    features: ['长文本处理', '安全可靠', '内容分析', '多轮对话', '创意写作'],
    price: '付费',
    适用场景: ['学术研究', '内容创作', '法律咨询', '数据分析'],
    website: 'https://www.anthropic.com',
    image: 'https://space.coze.cn/api/coze_space/gen_image?image_size=square&prompt=Claude%20AI%20interface%20showing%20long%20text%20processing&sign=95903dcd7f8fc352532ccd66371f26a8'
  },
  {
    id: 'gemini',
    name: 'Gemini',
    category: 'text',
    description: 'Google开发的多模态AI助手，支持文本、图像、音频等多种输入形式。',
    features: ['多模态处理', '实时信息', '代码生成', '创意写作', '知识问答'],
    price: '免费/付费',
    适用场景: ['内容创作', '学习研究', '技术开发', '信息检索'],
    website: 'https://gemini.google.com',
    image: 'https://space.coze.cn/api/coze_space/gen_image?image_size=square&prompt=Gemini%20AI%20interface%20showing%20multimodal%20features&sign=9bec9f38f98ddb8933e10fb16c7c49c3'
  },
  {
    id: 'copilot',
    name: 'GitHub Copilot',
    category: 'text',
    description: '由GitHub和OpenAI合作开发的AI编程助手，帮助开发者编写和优化代码。',
    features: ['代码自动完成', '代码解释', '测试生成', '重构建议', '多语言支持'],
    price: '付费',
    适用场景: ['软件开发', '代码学习', '项目重构', '技术研究'],
    website: 'https://github.com/features/copilot',
    image: 'https://space.coze.cn/api/coze_space/gen_image?image_size=square&prompt=GitHub%20Copilot%20coding%20assistant&sign=c9c34ffaaa220d4b4dc04226fac7f83f'
  },
  
  // AI绘图工具
  {
    id: 'midjourney',
    name: 'Midjourney',
    category: 'image',
    description: '通过文本提示生成高质量图像的AI工具，在Discord平台上运行。',
    features: ['图像生成', '艺术风格转换', '细节调整', '变体生成', '场景设计'],
    price: '付费',
    适用场景: ['艺术创作', '设计灵感', '内容制作', '概念设计'],
    website: 'https://www.midjourney.com',
    image: 'https://space.coze.cn/api/coze_space/gen_image?image_size=square&prompt=AI%20generated%20artwork%20created%20by%20Midjourney&sign=861c61b5ee307b8cfb098b487cbe6505'
  },
  {
    id: 'stable-diffusion',
    name: 'Stable Diffusion',
    category: 'image',
    description: '开源的AI图像生成模型，支持本地部署和自定义训练。',
    features: ['图像生成', '开源可定制', '本地部署', '模型微调', '文本到图像'],
    price: '免费/开源',
    适用场景: ['艺术创作', '软件开发', '研究实验', '内容制作'],
    website: 'https://stability.ai/stable-diffusion',
    image: 'https://space.coze.cn/api/coze_space/gen_image?image_size=square&prompt=Stable%20Diffusion%20AI%20art%20generation&sign=7a975c9468dd7847461f2e613be94b4c'
  },
  {
    id: 'dalle-3',
    name: 'DALL·E 3',
    category: 'image',
    description: 'OpenAI开发的先进图像生成模型，能够根据详细的文本描述创建精确的图像。',
    features: ['精确图像生成', '复杂场景', '风格多样', '文本理解', '创意表达'],
    price: '付费',
    适用场景: ['创意设计', '内容创作', '产品原型', '视觉辅助'],
    website: 'https://openai.com/dall-e-3',
    image: 'https://space.coze.cn/api/coze_space/gen_image?image_size=square&prompt=DALL-E%203%20AI%20generated%20artwork&sign=dc975f6b72d8dc6025cd618159324717'
  },
  {
    id: 'leonardo-ai',
    name: 'Leonardo AI',
    category: 'image',
    description: '专注于游戏和创意产业的AI图像生成平台，提供高质量的艺术资源。',
    features: ['游戏美术', '角色设计', '环境场景', '资产创建', '风格定制'],
    price: '免费/付费',
    适用场景: ['游戏开发', '动画制作', '概念设计', '插画创作'],
    website: 'https://leonardo.ai',
    image: 'https://space.coze.cn/api/coze_space/gen_image?image_size=square&prompt=Leonardo%20AI%20game%20art%20generation&sign=73ca47c310c09f4e64df17cbdfa10148'
  },
  {
    id: 'adobe-firefly',
    name: 'Adobe Firefly',
    category: 'image',
    description: 'Adobe开发的创意AI工具，与Creative Cloud集成，提供图像生成和编辑功能。',
    features: ['内容生成', '编辑增强', '风格转换', '字体生成', 'Adobe集成'],
    price: '免费/付费',
    适用场景: ['设计工作', '内容创作', '营销素材', '创意表达'],
    website: 'https://firefly.adobe.com',
    image: 'https://space.coze.cn/api/coze_space/gen_image?image_size=square&prompt=Adobe%20Firefly%20creative%20AI%20tools&sign=56eb6fa43589dc3a3fa78944c4c4f39f'
  },
  
  // AI视频工具
  {
    id: 'runway-ml',
    name: 'Runway ML',
    category: 'video',
    description: 'AI驱动的视频编辑平台，提供智能剪辑、特效和内容生成功能。',
    features: ['视频生成', '智能抠像', '对象移除', '风格迁移', '超分辨率'],
    price: '免费/付费',
    适用场景: ['视频制作', '内容创作', '广告营销', '电影后期'],
    website: 'https://runwayml.com',
    image: 'https://space.coze.cn/api/coze_space/gen_image?image_size=square&prompt=Runway%20ML%20video%20editing%20interface&sign=a57598760622581ef3d7e9665a043392'
  },
  {
    id: 'heygen',
    name: 'HeyGen',
    category: 'video',
    description: 'AI视频生成平台，专注于创建AI驱动的视频内容和数字人。',
    features: ['数字人生成', '视频翻译', '口型同步', '场景合成', '视频模板'],
    price: '付费',
    适用场景: ['内容营销', '培训视频', '虚拟主播', '多语言内容'],
    website: 'https://heygen.com',
    image: 'https://space.coze.cn/api/coze_space/gen_image?image_size=square&prompt=HeyGen%20AI%20video%20generation%20platform&sign=5e3f4ee5301cc9458bcc69da33657ed7'
  },
  {
    id: 'pika-labs',
    name: 'Pika Labs',
    category: 'video',
    description: 'AI视频生成平台，能够从文本或图像创建动态视频内容。',
    features: ['文本到视频', '图像动画', '风格转换', '视频修复', '创意视频'],
    price: '免费/付费',
    适用场景: ['内容创作', '社交媒体', '广告营销', '创意表达'],
    website: 'https://pika.art',
    image: 'https://space.coze.cn/api/coze_space/gen_image?image_size=square&prompt=Pika%20Labs%20AI%20video%20creation&sign=a97319beeb592dd08ad73285bd6237a2'
  },
  {
    id: 'descriptor',
    name: 'Descript',
    category: 'video',
    description: 'AI驱动的音视频编辑平台，提供文本式视频编辑和语音合成功能。',
    features: ['文本式编辑', '语音克隆', '自动字幕', '降噪处理', '多轨编辑'],
    price: '付费',
    适用场景: ['播客制作', '视频编辑', '内容创作', '教育培训'],
    website: 'https://www.descript.com',
    image: 'https://space.coze.cn/api/coze_space/gen_image?image_size=square&prompt=Descript%20AI%20audio%20and%20video%20editing&sign=7fcd70b4fd95dc436980c755ec481b36'
  },
  {
    id: 'synthesia',
    name: 'Synthesia',
    category: 'video',
    description: 'AI视频生成平台，允许用户通过文本创建专业的视频内容。',
    features: ['数字人生成', '多语言支持', '视频模板', '企业培训', '内容营销'],
    price: '付费',
    适用场景: ['企业培训', '营销视频', '产品演示', '教育内容'],
    website: 'https://www.synthesia.io',
    image: 'https://space.coze.cn/api/coze_space/gen_image?image_size=square&prompt=Synthesia%20AI%20video%20creation%20platform&sign=79b0cedbcba0e53d8248718cccbb4612'
  }
];

const ToolsPage: React.FC = () => {
  const { theme } = useTheme();
  const [selectedCategory, setSelectedCategory] = useState('all');
  const [filteredTools, setFilteredTools] = useState<Tool[]>(mockTools);
  const [searchTerm, setSearchTerm] = useState('');
  
  // 过滤工具
  useEffect(() => {
    let result = mockTools;
    
    // 按分类过滤
    if (selectedCategory !== 'all') {
      result = result.filter(tool => tool.category === selectedCategory);
    }
    
    // 按搜索词过滤
    if (searchTerm) {
      const term = searchTerm.toLowerCase();
      result = result.filter(tool => 
        tool.name.toLowerCase().includes(term) || 
        tool.description.toLowerCase().includes(term) ||
        tool.features.some(feature => feature.toLowerCase().includes(term)) ||
        tool.适用场景.some(scene => scene.toLowerCase().includes(term))
      );
    }
    
    setFilteredTools(result);
  }, [selectedCategory, searchTerm]);
  
  // 动画变体
  const fadeIn = {
    hidden: { opacity: 0, y: 20 },
    visible: { opacity: 1, y: 0, transition: { duration: 0.6 } }
  };
  
  const staggerContainer = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.1
      }
    }
  };
  
  return (
    <div className="py-24 bg-white dark:bg-gray-900 min-h-screen">
      <div className="container mx-auto px-4">
        {/* 页面标题 */}
        <motion.div 
          className="max-w-3xl mx-auto text-center mb-16"
          initial="hidden"
          animate="visible"
          variants={fadeIn}
        >
          <h1 className="text-4xl md:text-5xl font-bold mb-6 text-gray-800 dark:text-white">
            探索 AI 工具世界
          </h1>
          <p className="text-xl text-gray-600 dark:text-gray-400">
            从文本生成到视频创作，发现最适合你的AI助手
          </p>
        </motion.div>
        
        {/* 搜索框 */}
        <motion.div 
          className="max-w-2xl mx-auto mb-12"
          initial="hidden"
          animate="visible"
          variants={fadeIn}
          transition={{ delay: 0.2 }}
        >
          <div className="relative">
            <input
              type="text"
              placeholder="搜索工具、功能或适用场景..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full py-4 px-6 pr-12 rounded-xl border border-gray-200 dark:border-gray-700 bg-gray-50 dark:bg-gray-800 focus:outline-none focus:ring-2 focus:ring-blue-500 dark:focus:ring-blue-600 text-gray-800 dark:text-white"
            />
            <button 
              className="absolute right-4 top-1/2 transform -translate-y-1/2 text-gray-400 hover:text-gray-600 dark:hover:text-gray-300"
              onClick={() => setSearchTerm('')}
              aria-label="清除搜索"
            >
              <i className="fa-times-circle text-xl"></i>
            </button>
          </div>
        </motion.div>
        
        {/* 分类导航 */}
        <motion.div 
          className="flex flex-wrap justify-center gap-3 mb-12"
          initial="hidden"
          animate="visible"
          variants={staggerContainer}
        >
          {categories.map((category) => (
            <motion.button
              key={category.id}
              variants={fadeIn}
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              onClick={() => setSelectedCategory(category.id)}
              className={`flex items-center gap-2 px-5 py-3 rounded-full transition-all ${
                selectedCategory === category.id 
                  ? 'bg-blue-600 text-white shadow-lg' 
                  : 'bg-gray-100 dark:bg-gray-800 text-gray-700 dark:text-gray-300 hover:bg-gray-200 dark:hover:bg-gray-700'
              }`}
            >
              <i className={`fa-solid ${category.icon}`}></i>
              <span className="font-medium">{category.name}</span>
            </motion.button>
          ))}
        </motion.div>
        
        {/* 工具列表 */}
        <motion.div
          className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8"
          initial="hidden"
          animate="visible"
          variants={staggerContainer}
        >
          {filteredTools.map((tool) => (
            <motion.div 
              key={tool.id}
              variants={fadeIn}
              whileHover={{ y: -5, transition: { duration: 0.2 } }}
            >
              <ToolCard tool={tool} />
            </motion.div>
          ))}
        </motion.div>
        
        {/* 空状态 */}
        {filteredTools.length === 0 && (
          <motion.div 
            className="text-center py-16 max-w-xl mx-auto"
            initial="hidden"
            animate="visible"
            variants={fadeIn}
          >
            <div className="w-24 h-24 mx-auto mb-6 rounded-full bg-gray-100 dark:bg-gray-800 flex items-center justify-center">
              <i className="fa-search text-gray-400 text-4xl"></i>
            </div>
            <h3 className="text-xl font-bold mb-2 text-gray-800 dark:text-white">没有找到匹配的工具</h3>
            <p className="text-gray-600 dark:text-gray-400 mb-6">尝试使用不同的搜索词或浏览其他分类</p>
            <Button 
              onClick={() => {
                setSearchTerm('');
                setSelectedCategory('all');
              }}
              className="bg-blue-600 hover:bg-blue-700 text-white px-6 py-2 rounded-lg transition-all"
            >
              查看全部工具
            </Button>
          </motion.div>
        )}
      </div>
    </div>
  );
};

export default ToolsPage;