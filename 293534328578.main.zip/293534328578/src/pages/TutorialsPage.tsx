import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { useTheme } from '@/hooks/useTheme';
import { Button } from '@/components/Button';

// 教程类型定义
interface Tutorial {
  id: string;
  title: string;
  tool: string;
  category: string;
  level: 'beginner' | 'intermediate' | 'advanced';
  duration: string;
  image: string;
  description: string;
  steps: number;
}

// 模拟教程数据
const mockTutorials: Tutorial[] = [
  // 文本工具教程
  {
    id: 'chatgpt-beginner',
    title: 'ChatGPT 新手入门：从注册到基础使用',
    tool: 'ChatGPT',
    category: 'text',
    level: 'beginner',
    duration: '20 分钟',
    image: 'https://space.coze.cn/api/coze_space/gen_image?image_size=landscape_16_9&prompt=ChatGPT%20beginner%20tutorial%20interface&sign=f9455530fdedd6842e553dc7770fb437',
    description: '从零开始学习ChatGPT的注册流程和基础使用方法，掌握与AI对话的基本技巧。',
    steps: 6
  },
  {
    id: 'chatgpt-advanced',
    title: 'ChatGPT 进阶技巧：提示词工程实战指南',
    tool: 'ChatGPT',
    category: 'text',
    level: 'advanced',
    duration: '45 分钟',
    image: 'https://space.coze.cn/api/coze_space/gen_image?image_size=landscape_16_9&prompt=ChatGPT%20prompt%20engineering%20tutorial&sign=d0ff235d56ef9f1ed394b58f9f9063f9',
    description: '深入学习提示词工程技术，提高ChatGPT回复质量和准确性的高级技巧。',
    steps: 8
  },
  {
    id: 'notion-ai-beginner',
    title: 'Notion AI 完全指南：提升笔记和写作效率',
    tool: 'Notion AI',
    category: 'text',
    level: 'intermediate',
    duration: '30 分钟',
    image: 'https://space.coze.cn/api/coze_space/gen_image?image_size=landscape_16_9&prompt=Notion%20AI%20tutorial%20interface&sign=4799baeb4f12c04a451ff3ff7861a5a8',
    description: '学习如何在Notion中使用AI功能，包括文本生成、总结和优化内容。',
    steps: 7
  },
  
  // 绘图工具教程
  {
    id: 'midjourney-beginner',
    title: 'Midjourney 零基础入门：创建你的第一张AI artwork',
    tool: 'Midjourney',
    category: 'image',
    level: 'beginner',
    duration: '35 分钟',
    image: 'https://space.coze.cn/api/coze_space/gen_image?image_size=landscape_16_9&prompt=Midjourney%20beginner%20tutorial%20interface&sign=56a5ad6b1bdc760e395312fcd8ef3271',
    description: '从Discord设置到基础提示词，一步步学习如何使用Midjourney生成精美图像。',
    steps: 9
  },
  {
    id: 'midjourney-advanced',
    title: 'Midjourney 高级提示词技巧与风格控制',
    tool: 'Midjourney',
    category: 'image',
    level: 'advanced',
    duration: '50 分钟',
    image: 'https://space.coze.cn/api/coze_space/gen_image?image_size=landscape_16_9&prompt=Midjourney%20advanced%20prompt%20techniques&sign=85b781fbdc80686227d66bb1f9401cf7',
    description: '掌握Midjourney的高级提示词结构和风格控制方法，创建专业级AI艺术作品。',
    steps: 10
  },
  {
    id: 'stable-diffusion-beginner',
    title: 'Stable Diffusion 本地部署与基础使用',
    tool: 'Stable Diffusion',
    category: 'image',
    level: 'intermediate',
    duration: '60 分钟',
    image: 'https://space.coze.cn/api/coze_space/gen_image?image_size=landscape_16_9&prompt=Stable%20Diffusion%20local%20setup%20tutorial&sign=bd3a3282db81e49ab161d860059000c6',
    description: '学习如何在本地电脑部署Stable Diffusion，并掌握基本的图像生成技巧。',
    steps: 12
  },
  
  // 视频工具教程
  {
    id: 'runway-ml-beginner',
    title: 'Runway ML 视频编辑入门：AI驱动的创意制作',
    tool: 'Runway ML',
    category: 'video',
    level: 'beginner',
    duration: '40 分钟',
    image: 'https://space.coze.cn/api/coze_space/gen_image?image_size=landscape_16_9&prompt=Runway%20ML%20video%20editing%20tutorial&sign=138bbd52b0de8e2967801b2a0ec4c997',
    description: '学习Runway ML的基本功能，包括AI抠像、对象移除和视频风格转换。',
    steps: 8
  },
  {
    id: 'heygen-beginner',
    title: 'HeyGen 数字人生成：创建你的AI分身',
    tool: 'HeyGen',
    category: 'video',
    level: 'intermediate',
    duration: '45 分钟',
    image: 'https://space.coze.cn/api/coze_space/gen_image?image_size=landscape_16_9&prompt=HeyGen%20AI%20avatar%20creation%20tutorial&sign=31726cd0cab8c5c3accf4fae53c0e530',
    description: '学习如何使用HeyGen创建逼真的AI数字人，用于视频内容创作。',
    steps: 9
  },
  {
    id: 'pika-labs-beginner',
    title: 'Pika Labs 文本到视频：让你的创意动起来',
    tool: 'Pika Labs',
    category: 'video',
    level: 'beginner',
    duration: '35 分钟',
    image: 'https://space.coze.cn/api/coze_space/gen_image?image_size=landscape_16_9&prompt=Pika%20Labs%20text%20to%20video%20tutorial&sign=f3eaf9f5e6695371def5df7a8fefc85d',
    description: '学习如何使用Pika Labs从文本或图像创建动态视频内容，激发创意表达。',
    steps: 7
  }
];

const TutorialsPage: React.FC = () => {
  const { theme } = useTheme();
  const [selectedCategory, setSelectedCategory] = useState('all');
  const [selectedLevel, setSelectedLevel] = useState('all');
  const [filteredTutorials, setFilteredTutorials] = useState<Tutorial[]>(mockTutorials);
  const [searchTerm, setSearchTerm] = useState('');
  
  // 过滤教程
  React.useEffect(() => {
    let result = mockTutorials;
    
    // 按分类过滤
    if (selectedCategory !== 'all') {
      result = result.filter(tutorial => tutorial.category === selectedCategory);
    }
    
    // 按难度级别过滤
    if (selectedLevel !== 'all') {
      result = result.filter(tutorial => tutorial.level === selectedLevel);
    }
    
    // 按搜索词过滤
    if (searchTerm) {
      const term = searchTerm.toLowerCase();
      result = result.filter(tutorial => 
        tutorial.title.toLowerCase().includes(term) || 
        tutorial.tool.toLowerCase().includes(term) ||
        tutorial.description.toLowerCase().includes(term)
      );
    }
    
    setFilteredTutorials(result);
  }, [selectedCategory, selectedLevel, searchTerm]);
  
  // 分类和级别选项
  const categories = [
    { id: 'all', name: '全部工具', icon: 'fa-th-large' },
    { id: 'text', name: '文本工具', icon: 'fa-file-alt' },
    { id: 'image', name: '绘图工具', icon: 'fa-image' },
    { id: 'video', name: '视频工具', icon: 'fa-video' }
  ];
  
  const levels = [
    { id: 'all', name: '全部难度' },
    { id: 'beginner', name: '入门', icon: 'fa-graduation-cap' },
    { id: 'intermediate', name: '进阶', icon: 'fa-rocket' },
    { id: 'advanced', name: '高级', icon: 'fa-star' }
  ];
  
  // 获取级别对应的标签样式
  const getLevelBadge = (level: string) => {
    switch(level) {
      case 'beginner':
        return { text: '入门', color: 'bg-green-100 dark:bg-green-900/50 text-green-600 dark:text-green-400' };
      case 'intermediate':
        return { text: '进阶', color: 'bg-blue-100 dark:bg-blue-900/50 text-blue-600 dark:text-blue-400' };
      case 'advanced':
        return { text: '高级', color: 'bg-purple-100 dark:bg-purple-900/50 text-purple-600 dark:text-purple-400' };
      default:
        return { text: '全部', color: 'bg-gray-100 dark:bg-gray-800 text-gray-600 dark:text-gray-400' };
    }
  };
  
  // 动画变体
  const fadeIn = {
    hidden: { opacity: 0, y: 20 },
    visible: { opacity: 1, y: 0, transition: { duration: 0.6 } }
  };
  
  const staggerContainer = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.1
      }
    }
  };
  
  return (
    <div className="py-24 bg-white dark:bg-gray-900 min-h-screen">
      <div className="container mx-auto px-4">
        {/* 页面标题 */}
        <motion.div 
          className="max-w-3xl mx-auto text-center mb-16"
          initial="hidden"
          animate="visible"
          variants={fadeIn}
        >
          <h1 className="text-4xl md:text-5xl font-bold mb-6 text-gray-800 dark:text-white">
            AI 工具教程中心
          </h1>
          <p className="text-xl text-gray-600 dark:text-gray-400">
            从入门到精通，轻松掌握各种AI工具的使用技巧
          </p>
        </motion.div>
        
        {/* 搜索框 */}
        <motion.div 
          className="max-w-2xl mx-auto mb-12"
          initial="hidden"
          animate="visible"
          variants={fadeIn}
          transition={{ delay: 0.2 }}
        >
          <div className="relative">
            <input
              type="text"
              placeholder="搜索教程、工具名称或技巧..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full py-4 px-6 pr-12 rounded-xl border border-gray-200 dark:border-gray-700 bg-gray-50 dark:bg-gray-800 focus:outline-none focus:ring-2 focus:ring-blue-500 dark:focus:ring-blue-600 text-gray-800 dark:text-white"
            />
            <button 
              className="absolute right-4 top-1/2 transform -translate-y-1/2 text-gray-400 hover:text-gray-600 dark:hover:text-gray-300"
              onClick={() => setSearchTerm('')}
              aria-label="清除搜索"
            >
              <i className="fa-times-circle text-xl"></i>
            </button>
          </div>
        </motion.div>
        
        {/* 筛选器 */}
        <div className="mb-12">
          <div className="flex flex-col md:flex-row gap-6">
            {/* 工具分类筛选 */}
            <motion.div 
              className="flex-1"
              initial="hidden"
              animate="visible"
              variants={staggerContainer}
            >
              <h3 className="text-lg font-semibold mb-4 text-gray-800 dark:text-white">工具分类</h3>
              <div className="flex flex-wrap gap-3">
                {categories.map((category) => (
                  <motion.button
                    key={category.id}
                    variants={fadeIn}
                    whileHover={{ scale: 1.05 }}
                    whileTap={{ scale: 0.95 }}
                    onClick={() => setSelectedCategory(category.id)}
                    className={`flex items-center gap-2 px-4 py-2 rounded-full transition-all ${
                      selectedCategory === category.id 
                        ? 'bg-blue-600 text-white shadow-md' 
                        : 'bg-gray-100 dark:bg-gray-800 text-gray-700 dark:text-gray-300 hover:bg-gray-200 dark:hover:bg-gray-700'
                    }`}
                  >
                    <i className={`fa-solid ${category.icon}`}></i>
                    <span>{category.name}</span>
                  </motion.button>
                ))}
              </div>
            </motion.div>
            
            {/* 难度级别筛选 */}
            <motion.div 
              className="flex-1"
              initial="hidden"
              animate="visible"
              variants={staggerContainer}
              transition={{ delay: 0.1 }}
            >
              <h3 className="text-lg font-semibold mb-4 text-gray-800 dark:text-white">难度级别</h3>
              <div className="flex flex-wrap gap-3">
                {levels.map((level) => (
                  <motion.button
                    key={level.id}
                    variants={fadeIn}
                    whileHover={{ scale: 1.05 }}
                    whileTap={{ scale: 0.95 }}
                    onClick={() => setSelectedLevel(level.id)}
                    className={`flex items-center gap-2 px-4 py-2 rounded-full transition-all ${
                      selectedLevel === level.id 
                        ? 'bg-blue-600 text-white shadow-md' 
                        : 'bg-gray-100 dark:bg-gray-800 text-gray-700 dark:text-gray-300 hover:bg-gray-200 dark:hover:bg-gray-700'
                    }`}
                  >
                    {level.icon && <i className={`fa-solid ${level.icon}`}></i>}
                    <span>{level.name}</span>
                  </motion.button>
                ))}
              </div>
            </motion.div>
          </div>
        </div>
        
        {/* 教程列表 */}
        <motion.div
          className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8"
          initial="hidden"
          animate="visible"
          variants={staggerContainer}
        >
          {filteredTutorials.map((tutorial) => {
            const levelBadge = getLevelBadge(tutorial.level);
            return (
              <motion.div 
                key={tutorial.id}
                className="bg-white dark:bg-gray-900 rounded-xl overflow-hidden shadow-lg border border-gray-200 dark:border-gray-700"
                variants={fadeIn}
                whileHover={{ y: -5, transition: { duration: 0.2 } }}
              >
                {/* 教程缩略图 */}
                <div className="h-48 relative overflow-hidden">
                  <img 
                    src={tutorial.image} 
                    alt={tutorial.title} 
                    className="w-full h-full object-cover transition-transform duration-700 hover:scale-110"
                    loading="lazy"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/70 to-transparent flex items-end">
                    <div className="p-4 w-full flex justify-between items-center">
                      <div className="flex items-center gap-2">
                        <span className={`text-xs font-medium px-2 py-1 rounded-full ${levelBadge.color}`}>
                          {levelBadge.text}
                        </span>
                        <span className="text-white text-sm">
                          <i className="fa-clock mr-1"></i> {tutorial.duration}
                        </span>
                      </div>
                      <span className="bg-white/20 backdrop-blur-sm text-white text-xs px-2 py-1 rounded-full">
                        {tutorial.steps} 步
                      </span>
                    </div>
                  </div>
                </div>
                
                {/* 教程信息 */}
                <div className="p-6">
                  {/* 工具名称 */}
                  <div className="flex items-center gap-2 mb-3">
                    <span className={`text-xs font-medium px-2 py-1 rounded-full ${
                      tutorial.category === 'text' 
                        ? 'bg-blue-100 dark:bg-blue-900/50 text-blue-600 dark:text-blue-400' 
                        : tutorial.category === 'image'
                        ? 'bg-purple-100 dark:bg-purple-900/50 text-purple-600 dark:text-purple-400'
                        : 'bg-red-100 dark:bg-red-900/50 text-red-600 dark:text-red-400'
                    }`}>
                      {tutorial.tool}
                    </span>
                  </div>
                  
                  {/* 教程标题 */}
                  <h3 className="text-xl font-bold mb-3 text-gray-800 dark:text-white line-clamp-2">
                    {tutorial.title}
                  </h3>
                  
                  {/* 教程描述 */}
                  <p className="text-gray-600 dark:text-gray-400 mb-4 line-clamp-2">
                    {tutorial.description}
                  </p>
                  
                  {/* 操作按钮 */}
                  <Button 
                    href={`/tutorials/${tutorial.id}`}
                    className="w-full bg-blue-600 hover:bg-blue-700 text-white py-3 rounded-lg font-medium transition-all"
                  >
                    开始学习
                    <i className="fa-arrow-right ml-2"></i>
                  </Button>
                </div>
              </motion.div>
            );
          })}
        </motion.div>
        
        {/* 空状态 */}
        {filteredTutorials.length === 0 && (
          <motion.div 
            className="text-center py-16 max-w-xl mx-auto"
            initial="hidden"
            animate="visible"
            variants={fadeIn}
          >
            <div className="w-24 h-24 mx-auto mb-6 rounded-full bg-gray-100 dark:bg-gray-800 flex items-center justify-center">
              <i className="fa-book-open text-gray-400 text-4xl"></i>
            </div>
            <h3 className="text-xl font-bold mb-2 text-gray-800 dark:text-white">没有找到匹配的教程</h3>
            <p className="text-gray-600 dark:text-gray-400 mb-6">尝试使用不同的搜索词或筛选条件</p>
            <Button 
              onClick={() => {
                setSearchTerm('');
                setSelectedCategory('all');
                setSelectedLevel('all');
              }}
              className="bg-blue-600 hover:bg-blue-700 text-white px-6 py-2 rounded-lg transition-all"
            >
              查看全部教程
            </Button>
          </motion.div>
        )}
      </div>
    </div>
  );
};

export default TutorialsPage;